<div id="styleSelector">
</div>

</div>
</div>
</div>
</div>


<!--[if lt IE 10]>
    <div class="ie-warning">
        <h1>Warning!!</h1>
        <p>You are using an outdated version of Internet Explorer, please upgrade
            <br/>to any of the following web browsers to access this website.
        </p>
        <div class="iew-container">
            <ul class="iew-download">
                <li>
                    <a href="http://www.google.com/chrome/">
                        <img src="<?php echo base_url(); ?>assets/files/assets/images/browser/chrome.png" alt="Chrome">
                        <div>Chrome</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.mozilla.org/en-US/firefox/new/">
                        <img src="<?php echo base_url(); ?>assets/files/assets/images/browser/firefox.png" alt="Firefox">
                        <div>Firefox</div>
                    </a>
                </li>
                <li>
                    <a href="http://www.opera.com">
                        <img src="<?php echo base_url(); ?>assets/files/assets/images/browser/opera.png" alt="Opera">
                        <div>Opera</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.apple.com/safari/">
                        <img src="<?php echo base_url(); ?>assets/files/assets/images/browser/safari.png" alt="Safari">
                        <div>Safari</div>
                    </a>
                </li>
                <li>
                    <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                        <img src="<?php echo base_url(); ?>assets/files/assets/images/browser/ie.png" alt="">
                        <div>IE (9 & above)</div>
                    </a>
                </li>
            </ul>
        </div>
        <p>Sorry for the inconvenience!</p>
    </div>
<![endif]-->


<script data-cfasync="false" src="<?php echo base_url(); ?>assets/files/assets/js/email-decode.min.js"></script><script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/jquery/js/jquery.min.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/popper.js/js/popper.min.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/bootstrap/js/bootstrap.min.js"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/waves/js/waves.min.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>

<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
<script type="dfbc13150741043d6936d463-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/modernizr/js/modernizr.js"></script><script type="dfbc13150741043d6936d463-text/javascript" src="<?php echo base_url(); ?>assets/files/bower_components/modernizr/js/css-scrollbars.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/jquery.dataTables.min.js"></script>

<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/dataTables.buttons.min.js"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/chart/float/jquery.flot.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/pages/chart/float/jquery.flot.categories.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/pages/chart/float/curvedLines.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/pages/chart/float/jquery.flot.tooltip.min.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/files/bower_components/chartist/js/chartist.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/widget/amchart/amcharts.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/pages/widget/amchart/serial.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/pages/widget/amchart/light.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/data-table/js/jszip.min.js" type="dfbc13150741043d6936d463-text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/data-table/js/vfs_fonts.js" type="dfbc13150741043d6936d463-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/bower_components/datatables.net-buttons/js/buttons.print.min.js" type="dfbc13150741043d6936d463-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/bower_components/datatables.net-buttons/js/buttons.html5.min.js" type="dfbc13150741043d6936d463-text/javascript"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/dataTables.bootstrap4.min.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/responsive.bootstrap4.min.js"></script>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/data-table-custom.js"></script>
<script type="dfbc13150741043d6936d463-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/script.js"></script>


<script src="<?php echo base_url(); ?>assets/files/assets/js/pcoded.min.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/js/vertical/vertical-layout.min.js" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/files/assets/js/jquery.mCustomScrollbar.concat.min.js" type="dfbc13150741043d6936d463-text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/files/assets/pages/data-table/js/pdfmake.min.js" type="dfbc13150741043d6936d463-text/javascript"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/pages/dashboard/custom-dashboard.min.js"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript" src="<?php echo base_url(); ?>assets/files/assets/js/script.min.js"></script>




<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="3af5b6b5f1a1f808b182c1ef-text/javascript"></script>
<script type="3af5b6b5f1a1f808b182c1ef-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script src="<?php echo base_url(); ?>assets/files/assets/js/rocket-loader.min.js" data-cf-settings="3af5b6b5f1a1f808b182c1ef-|49" defer=""></script></body>

<!-- Mirrored from colorlib.com//polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Sep 2019 13:16:44 GMT -->
</html>
