                 
<!-- start product page -->
    <div class="container-fluid">
    	 <h1><?php 
            if(isset($product['title']['sub_cat_name'])){
      echo $product['title']['sub_cat_name'];
    }else if($product['title']['cate_name']){
           echo $product['title']['cate_name'];
    }
else{
   echo $product['title']['sub_child_name'];

}
      ?></h1>

      <div class="row">
        <div class="col-lg-10 col-sm-12"> <h1>Products </h1>  </div>
        <div class="col-lg-2 col-sm-12">Button <img src="" alt="">  </div>
      </div>
 
   
    <div class="row">
    	<h1>   

        <?php if(isset($product['productdata']) && $product['productdata']!=""){

        foreach($product['productdata'] as $value){ ?>
        <div class="col-md-3">

            <div class="dress-card">
            <div class="dress-card-head">
                <img class="dress-card-img-top" src="<?php echo base_url(); ?>assets/images/<?php echo $value['pro_feat_image']; ?>" alt="">
                <div class="surprise-bubble"><span class="dress-card-heart">
                    <i class="fas fa-heart"></i>
                </span><a href="#"> <span>More</span></a></div>
            </div>
            <div class="dress-card-body">
                <!-- <h4 class="dress-card-title">Harpa</h4> -->
                <p class="dress-card-para"><?php echo $value['pro_name']; ?></p>
                <p class="dress-card-para"><span class="dress-card-price">Rs.<?php echo $value['pro_sale_price']; ?> &ensp;</span><span class="dress-card-crossed">Rs.<?php echo $value['pro_price']; ?></span><span class="dress-card-off">&ensp;(60% OFF)</span></p>
                <div class="row">
                <div class="col-md-6 card-button"><a   href="javascript:void(0);" onclick="add_to_cart('<?php echo $value['pro_id']; ?>','<?php  echo $value['pro_sale_price'];  ?>','1')"><div class="card-button-inner bag-button" style="">Add to Bag</div></a></div>
                <div class="col-md-6 card-button"><a  href="javascript:void(0);" onclick="add_to_wishlist('<?php echo $value['pro_id']; ?>')"><div class="card-button-inner wish-button">Whishlist</div></a></div>
                </div>
            </div>
			</div>
			<!-- 2nd -->
			<!--  -->
        </div>
        <?php  }}?>

        
        </div>

    </div>

    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      	<div class="row">
      		<div class="col-lg-9 col-sm-12"><h5 class="modal-title" id="exampleModalLabel" hidden="">Product Page / T-shirt</h5></div>
      		<div class="col-lg-3 col-sm-12"><button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button></div>
      	</div>
        
        
      </div>
      <div class="modal-body">

      	<section>
      		<div class="row">
      			<div class="col-lg-4 col-sm-12">
      				<h4>Brand</h4>
      				<input type="checkbox" value="puma"> Puma <br>
      				<input type="checkbox" value="puma"> Duke <br>
      				<input type="checkbox" value="puma"> Reebok


      			</div>
      			<div class="col-lg-4 col-sm-12">
      				<h4>Price</h4>
      				<input type="checkbox" value="puma"> Rs.200 to Rs.500 <br>
      				<input type="checkbox" value="puma"> Rs.500 to Rs. 800 <br>
      				
      			</div>
      			<div class="col-lg-4 col-sm-12">
      				<h4>Color</h4>
      				<input type="checkbox" value="puma"> Red <br>
      				<input type="checkbox" value="puma"> Green <br>
      				<input type="checkbox" value="puma"> Blue
      			</div>
      		</div>
      	</section>


      </div>
      <div class="modal-footer">        
        <button type="button" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>
  <script type="text/javascript"> $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})  </script>


            <?php
             $session_value=isset($_SESSION['user_id']);
      ?>

<script type="text/javascript">
  var session_value = "<?php echo $session_value ?>";
  // alert(session_value);

  function add_to_cart(id,c_price,c_quantity)
  {
      if (typeof session_value == "undefined" || session_value == ""){
            window.location.href = "<?php echo site_url(); ?>Dashboard/register";
  
           }else{
                         $.post("<?php echo site_url(); ?>/Ajaxcontroller/add_to_cart",{ 'pro_id' : id,'c_price' : c_price, 'c_quantity' : c_quantity},function(data, status){
                          alert(data);

                     if (status=="success") {
                     $.post("<?php echo site_url(); ?>/Ajaxcontroller/quantity",function(data, status){
                        $("#result").html(data);
                      
                   });
                 }
        

  });
        

           }

           }
              
</script>

<script type="text/javascript">
  var session_value = "<?php echo $session_value ?>";
  // alert(session_value);
  function add_to_wishlist(id)
  {
      if (typeof session_value == "undefined" || session_value == null){
            window.location.href = "<?php echo site_url(); ?>Dashboard/register";
  
           }else{
                         $.post("<?php echo site_url(); ?>/Ajaxcontroller/add_to_wishlist",{ 'pro_id' : id},function(data, status){
                     if (status=="success") {
                     $.post("<?php echo site_url(); ?>/Ajaxcontroller/wishliat",function(data, status){
                        $("#wishlist").html(data);
                      alert('Wishlist  Add Sucessfully');
                   });
                 }
        

  });
        

           }

           }
           
</script>

<!-- end of product page -->

        <!-- Footer
        ============================================= -->

       