<section id='content' class='' >
<div >
	<?php $top_banner = $this->Dashboard_model->top_banner(); 


	?>
	<div class="banner_pic" >
	<img src="<?php echo base_url(); ?>/assets/images/<?php echo $top_banner['b_image']; ?>" width="100%">
	
    </div>
<div class="fl-row fl-row-full-width fl-row-bg-photo fl-node-559d4fa261024" data-node="559d4fa261024">
	
	<div class="fl-row-content-wrap">
			
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-559d4fa26140c" data-node="559d4fa26140c">
			<div class="pic_over">
			<div class="col-md-6">
				<button id="m_shop" style="width: auto;" >Shop For Women</button>
			</div>
			
	</div>
	<div class="pic_over2">
			<div class="col-md-6">
				<button id="w_shop"style="width: auto;">Shop For men</button>
			</div>
			
	</div>
			<?php foreach ($category as $key => $value) {
			
			 ?>
		<div class="fl-col fl-col-small fl-node-559d4fa2617f4" style="width: 33.33%;" data-node="559d4fa2617f4">
		<div class="fl-col-content fl-node-content">
		<div class="fl-module fl-module-details_thumb fl-animation fl-slide-down fl-node-56134238c4329" data-node="56134238c4329"  data-animation-delay="0.25" >
	<div class="fl-module-content fl-node-content">
		<div class="feature-box  media-box fbox-bg" >

	
	    <div class="fbox-media">
    	<a href='<?php echo base_url(); ?>get-product/<?php 
								echo 'cat';?>/<?php echo $value['cat_id']; ?>' >
        	<img src="<?php echo base_url(); ?>assets/images/<?php echo $value['category_image']; ?>"  alt='' />
        </a>

                   
	</div>
    <div class="fbox-desc">
        <h3><?php echo $value['cate_name']; ?><span class="subtitle">For Men and Women</span></h3>
            </div>
</div>	</div>
</div>		</div>
	</div>
<?php }?>
	</div>		</div>
	</div>
</div><div class="fl-row fl-row-full-width fl-row-bg-photo fl-row-bg-overlay dark fl-node-561b4db55ba55" data-node="561b4db55ba55">
	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-561b4db5696d0" data-node="561b4db5696d0">
			<center>	


						<h1 style="color:#e6e6e6;"><?php echo $get_winter['cate_name'];?></h1> </center>

				<?php $data1 = $this->Dashboard_model->get_subcate($get_winter['cat_id']);
							// print_r($data1);
							foreach ($data1 as $key => $value) {

								
							
				 ?>

			<div class="fl-col fl-col-small fl-node-561b4db569887" style="width: 25%;" data-node="561b4db569887">
		
				<div class="fl-col-content fl-node-content">
			
		<div class="fl-module fl-module-features_thumb fl-animation fl-slide-up fl-node-561b4dc7020eb" data-node="561b4dc7020eb"  data-animation-delay="0.25" >

			<div class="fl-module-content fl-node-content">
		
		<div class="feature-box fbox-center fbox-effect fbox-light">
				
    <div class="fbox-icon" >

         <a  href="#" >
            <img src="<?php echo base_url(); ?>/assets/images/<?php echo $value['sabcat_image']; ?>" width="50%">
        </a>
    </div>

    
    <h3><?php echo $value['sub_cat_name']; ?></h3>
        <p>Best collection for men and women</p>
    </div>	</div>
</div>		</div>
	</div>
<?php }?>
	
	</div>		</div>
	</div>
</div>

	<?php $bags = $this->Dashboard_model->get_bags(); 
	?>

<div class="fl-row fl-row-full-width fl-row-bg-none fl-node-56204435158eb" data-node="56204435158eb">
	
</div><div class="fl-row fl-row-full-width fl-row-bg-parallax fl-row-bg-overlay fl-node-559d4fa263b1c" data-node="559d4fa263b1c" data-parallax-speed="2" data-parallax-image="<?php echo base_url(); ?>/assets/images/<?php echo $bags['category_image']; ?>">
	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-559d4fa263f04" data-node="559d4fa263f04">
		<div class="fl-col fl-node-559d4fa2642ec" style="width: 100%;" data-node="559d4fa2642ec">
		<div class="fl-col-content fl-node-content">
		<div class="fl-module fl-module-image_bg_cta fl-animation fl-fade-in fl-node-559d4fa2646d4" data-node="559d4fa2646d4"  data-animation-delay="0.25" >
	<div class="fl-module-content fl-node-content">
		<div class="section notopmargin nobottommargin notopborder dark" style="padding: 220px 0px;background:none;" >            
    <div class=" vertical-middle center clearfix" style="position: absolute; top: 50%; width: 100%; margin-top: -123px;">
        <div class="emphasis-title heading-block">

            <h3 style="font-size: 36px;"  data-animate="fadeInDown" ><?php echo $bags['cate_name']; ?></h3>
            <span data-animate='fadeIn' >For Men & Women </span>
        </div>
		<a href="#" data-animate="none"  href="#" class="none animated button      button-reveal tright button-3d button-medium  " >
	<span>See More</span>
	 
	<i class="icon-chevron-right"></i>
	</a>  

    </div>                           
</div>	</div>
</div>		</div>
	</div>
	</div>		</div>
	</div>
</div><div class="fl-row fl-row-full-width fl-row-bg-photo fl-node-5685f4ba35197" data-node="5685f4ba35197">
	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-5685f4ba44026" data-node="5685f4ba44026">
		<div class="fl-col fl-node-5685f4ba44270" style="width: 100%;" data-node="5685f4ba44270">
		<div class="fl-col-content fl-node-content">
		<div class="fl-module fl-module-rich-text fl-node-5685f4ba349cf" data-node="5685f4ba349cf"  data-animation-delay="0.0" >
	<div class="fl-module-content fl-node-content">
		<center><h1>Letest Product</h1></center>
		<div class="fl-rich-text">
	<p><div class="woocommerce columns-4">
		
			
			<ul class="products">

			<?php $product = $this->Dashboard_model->get_latest_product(); 
							if(isset($product) && $product!=''){
								foreach ($product as $key => $value) {
									# code...
								
		?>

				
					 <li class="post-3513 product type-product status-publish has-post-thumbnail product_cat-clothes-rack  instock shipping-taxable purchasable product-type-simple">
	<a href="" class="woocommerce-LoopProduct-link"><img src="<?php echo base_url(); ?>/assets/images/<?php echo $value['pro_feat_image'];?>" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="product-18" title="product-18" srcset="" sizes="(max-width: 300px) 100vw, 300px" /><h3><?php echo $value['pro_name']; ?></h3>

	<span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">RS </span><?php echo $value['pro_sale_price']; ?></span></span>
</a><a rel="nofollow" data-quantity="1" data-product_id="3512" data-product_sku="" class="button product_type_simple add_to_cart_button ajax_add_to_cart"  href="javascript:void(0);" onclick="add_to_cart('<?php echo $value['pro_id']; ?>','<?php  echo $value['pro_sale_price'];  ?>','1')" >Add to cart</a></li>
<?php } }?>
				
			</ul>

			
			</div></p></div>	</div>
</div>		</div>
	</div>
	</div>		</div>
	</div>
</div><div class="fl-row fl-row-full-width fl-row-bg-parallax dark fl-node-559d4fa2675b5" data-node="559d4fa2675b5" data-parallax-speed="2" data-parallax-image="<?php echo base_url(); ?>/assets/wp-content/uploads/2015/07/11.jpg">
	<a href="">	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-559d4fa26799d" data-node="559d4fa26799d">
		<div class="fl-col fl-node-559d4fa267d85" style="width: 100%;" data-node="559d4fa267d85">
		<div class="fl-col-content fl-node-content">
		<div class="fl-module fl-module-twitter_slider fl-animation fl-slide-up fl-node-559d4fa26816d" data-node="559d4fa26816d"  data-animation-delay="0.25" >
	<div class="fl-module-content fl-node-content">
		<div style="padding: 110px 0px; " >
	<div class="testimonial-transparent-light " data-animation="slide" data-arrows="false">
		
		<div class="flexslider" style="width: auto;">
			<div class="slider-wrap">
<center><b style="font-size:45px !important; color:#ef6363 !important;">Footwear For Men & Women</b><br>
  <button id="foot_btn"style="width:auto;"> <a href="" style="color:black; font-weight: bold; font-size:16px; ">View all</a></button>
</center>
			</div>
		</div>
	</div>
</div>

	</div>
</div>		</div>
	</div>
	</div>		</div>
	</div></a>
</div></div>

</section>
            <?php
             $session_value=isset($_SESSION['user_id']);
 			?>

<script type="text/javascript">
	var session_value = "<?php echo $session_value ?>";
	// alert(session_value);

  function add_to_cart(id,c_price,c_quantity)
  {
  		if (typeof session_value == "undefined" || session_value == ""){
  			   	window.location.href = "<?php echo site_url(); ?>Dashboard/register";
  
           }else{
           	             $.post("<?php echo site_url(); ?>/Ajaxcontroller/add_to_cart",{ 'pro_id' : id,'c_price' : c_price, 'c_quantity' : c_quantity},function(data, status){
           	             	alert(data);

                     if (status=="success") {
                     $.post("<?php echo site_url(); ?>/Ajaxcontroller/quantity",function(data, status){
                        $("#result").html(data);
                      
                   });
                 }
  			

  });
        

           }

           }
              
</script>





        <!-- Footer
        ============================================= -->
