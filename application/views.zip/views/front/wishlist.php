<!DOCTYPE html>
<html lang="en-US" >

<!-- Mirrored from ignitethemes.net/wp/rhapsody/home3/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Oct 2019 05:56:22 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<title>Vastr&#8211;Home</title>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://css3-mediaqueries-js.googlecode.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Rhapsody &raquo; Feed" href="http://ignitethemes.net/wp/rhapsody/feed/" />
<link rel="alternate" type="application/rss+xml" title="Rhapsody &raquo; Comments Feed" href="http://ignitethemes.net/wp/rhapsody/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Rhapsody &raquo; Home3 Comments Feed" href="feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ignitethemes.net\/wp\/rhapsody\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.15"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
#footer .wpcf7-form-control-wrap textarea, .sidebar .wpcf7-form-control-wrap textarea{
    margin-left: 5px !important
    
    ;
}
.dark #footer .wpcf7-form-control.wpcf7-submit, #footer .wpcf7-form-control.wpcf7-submit {
    
    margin-left: 6px !important;
}
</style>
<link rel='stylesheet'  href='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/css/form.css' type='text/css' media='' />
<link rel='stylesheet'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/product.css' type='text/css' media='' />
<link rel='stylesheet' id='via-google-fonts1-css'  href='https://fonts.googleapis.com/css?family=PT+Sans:400,700' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/bootstrap55a0.css?ver=3.2.0' type='text/css' media='' />
<link rel='stylesheet' id='via-main-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/style988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-main-dark-style-css'  href='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/css/dark988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-font-icons-style-css'  href='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/css/font-icons988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-main-dark-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/dark988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-font-icons-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/font-icons988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-animate-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/animate988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-magnific-popup-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/magnific-popup988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-responsive-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/css/responsive988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-svn-fix-ie-style-css'  href='css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries988b.html?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='via-rs-plugin-style-css'  href='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/include/rs-plugin/css/settings988b.css?ver=20152306' type='text/css' media='' />
<link rel='stylesheet' id='fl-builder-layout-2983-css'  href='<?php echo base_url(); ?>assets/wp-content/uploads/bb-plugin/cache/2983-layout6b2c.css?ver=9c2dfa887b6cef9e2d5b79637a8e5163' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='<?php echo base_url(); ?>assets/wp-content/plugins/contact-form-7431/includes/css/styles5b31.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='<?php echo base_url(); ?>assets/wp-content/plugins/revslider/rs-plugin/css/settings1dc6.css?ver=4.6.5' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}
</style>
<link rel='stylesheet' id='tp-open-sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C600%2C700&amp;ver=4.6.15' type='text/css' media='all' />
<link rel='stylesheet' id='tp-raleway-css'  href='http://fonts.googleapis.com/css?family=Raleway%3A200%2C600&amp;ver=4.6.15' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/css/woocommerce-layouta117.css?ver=2.6.11' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreena117.css?ver=2.6.11' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/css/woocommercea117.css?ver=2.6.11' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/js/jquerya4e6.js?ver=1.11.0'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/js/plugins988b.js?ver=20152306'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/include/rs-plugin/js/jquery.themepunch.tools.min988b.js?ver=20152306'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/include/rs-plugin/js/jquery.themepunch.revolution.min988b.js?ver=20152306'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min1dc6.js?ver=4.6.5'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min1dc6.js?ver=4.6.5'></script>
<link rel='https://api.w.org/' href='http://ignitethemes.net/wp/rhapsody/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ignitethemes.net/wp/rhapsody/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ignitethemes.net/wp/rhapsody/wp-includes/wlwmanifest.xml" /> 

<link rel="canonical" href="index.html" />
<link rel='shortlink' href='http://ignitethemes.net/wp/rhapsody/?p=2983' />
<link rel="alternate" type="application/json+oembed" href="http://ignitethemes.net/wp/rhapsody/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fignitethemes.net%2Fwp%2Frhapsody%2Fhome3%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://ignitethemes.net/wp/rhapsody/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fignitethemes.net%2Fwp%2Frhapsody%2Fhome3%2F&amp;format=xml" />
		
				<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		
</head>
<body class="page page-id-2983 page-template-default dark stretched fl-builder" >

    
    <!-- Document Wrapper
    ============================================= -->
    <div id="wrapper" class="clearfix">
    
         <!-- Header
============================================= -->


<header id="header"  class='transparent-header full-header' >

    <div id="header-wrap">

        <div class="container clearfix">

            <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>
            
            <!-- Logo
            ============================================= -->
            <div id="logo">
               <a href="<?php echo base_url(); ?>" class="standard-logo" data-dark-logo=""  ><img src="<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/images/logo.png" width="100%"  alt="Logo" ></a>
                <a href="index.html" class="retina-logo"   ><img src="index.html" alt="Retina Logo"  ></a>   
 
                
            </div><!-- #logo end -->         
            

			<nav id="primary-menu">


				<ul>
				<?php 
	
				$category = $this->Dashboard_model->all_cat();
				foreach ($category as $key => $value) {
				?>
		
				     
		<li class='mega-menu sub-menu '>
			<a class='megamenu' href="<?php echo base_url(); ?>get-product/<?php 
								echo 'cat' ;?>/<?php echo $value['cat_id']; ?>"><?php echo $value['cate_name']; ?></a>
					<div class="mega-menu-content style-2 col-5 clearfix" >
						<?php $sub = $this->Dashboard_model->all_subcat();
				foreach ($sub as $key => $value1) {
					if($value1['category_id'] == $value['cat_id']){
					
				?>
				
		
					<ul class="dropdown">
			
					   <li class='mega-menu-title sub-menu '><a href="<?php echo base_url(); ?>get-product/<?php 
								echo 'subcat';?>/<?php echo $value1['sub_id']; ?>" ><?php echo $value1['sub_cat_name']; ?></a>
			<?php 

			$subchild = $this->Dashboard_model->all_subchild();
			// print_r($subchild);
			if(isset($subchild) && $subchild!=''){
				foreach ($subchild as $key => $value2) {
					if($value2['sub_id'] == $value1['sub_id']){
					
				?>
						<ul>

						   <li class=''><a href="<?php echo base_url(); ?>get-product/<?php echo 'subchild'?>/<?php echo $value2['id']?>" ><?php echo $value2['sub_child_name']; ?></a></li>
						</ul>
						<?php }}}?>

					    </li>
					    	
					
					</ul>
					<?php }}?>
					</div>
				</li>
			<?php } ?>


				   <li style="text-align: center !important;" class='sub-menu ' ><a href='#' ><input type="search" id="srch" placeholder="search"></a>
					<div class="search_icon">
						<button id="my_sch"><img src="<?php echo base_url(); ?>/assets/images/search.png" width="20%"></button>
 
					</div>
				   </li>
	<?php 
    $res = $this->Dashboard_model->count_cart();
    $res1 = $this->Dashboard_model->wishliat();
  
   ?>
				   <li style="text-align: center !important;" class='sub-menu ' ><a href='<?php echo site_url(); ?>cart-item' >
				  <img src="<?php echo base_url(); ?>/assets/images/shop.png" width="70%" ></a>
				   	<div id="result" style="z-index: 9; margin-top: -57px; font-size:18px;"><?php echo $res; ?></div>				 
				   	<!-- <span ></span> -->
				
				   </li>
				   <li style="text-align: center !important;" class='sub-menu ' ><a href='<?php echo site_url(); ?>wishlist' ><img src="<?php echo base_url(); ?>/assets/images/wishlist.png" width="70%"></a>
				
				   </li>
				   <li class='sub-menu ' ><a href='form.html' ><img src="<?php echo base_url(); ?>/assets/images/profile.png" width="70%"></a>
				   	 	<div id="wishlist" style="z-index: 9;
    margin-top: -59px;
    margin-left: -31px;
    font-size: 18px;
    font-weight: bold;">
				   	 		<?php echo $res1; ?></div>
					
					<ul style="width:120%; ">
					<!-- <li class=''><a href='form.html' >Login</a></li> -->
					<li class=''><a href='<?php echo base_url(); ?>ulogout' >Sign Up</a></li>
				   </ul>
				   </li>

				  
				 
				
				
			
			</ul>
			</nav>             
            
        </div>

  </div>

</header><!-- #header end -->
<div class="container wish_l">
    <p class="tital">
    <span style="font-size:25px;">Wish list</span> &nbsp <span style="font-size:50px;"id="wishlist" >
    	<?php
    $res1 = $this->Dashboard_model->wishliat();
     echo $res1; ?></div></span>
    </p>
    <section class="wishlist-page component" data-component="Wishlist">
    <div id="wishlist">
    	<?php

    	 if(isset($wish_item) && $wish_item){
    		foreach ($wish_item as $key => $value) {
     ?>
        <div class="product">
        <figure>
            <a class="redirect" href="" onclick="s_objectID=&quot;https://breakfix.anntaylor.com/long-sleeve-tee/383500?skuId=19582337&amp;defaultColor=1246&amp;prodId=383_1&quot;;return this.s_oc?this.s_oc(e):true">
            <img src="<?php echo base_url(); ?>assets/images/<?php echo $value['pro_feat_image']; ?>" alt="Long Sleeve Tee">
            </a>
        </figure>
        <h1 class="name">
            <a href="" onclick="s_objectID=&quot;https://breakfix.anntaylor.com/long-sleeve-tee/383500?skuId=19582337&amp;defaultColor=1246&amp;prodId=383_2&quot;;return this.s_oc?this.s_oc(e):true"><?php echo $value['pro_name']; ?></a>
        </h1>
        <aside class="style">Style #383500</aside> 
        <strong class="price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
            <span itemprop="price">र <?php echo $value['pro_sale_price']; ?></span>
            <meta itemprop="priceCurrency" content="र ">
            <link itemprop="availability" href="http://schema.org/InStock" content="In Stock">
        </strong>
        <div class="selection">
            <span class="type-heading">Size Type:</span>
            <em>Regular</em><br>
            <span class="size-heading">Size:</span>
            <em><?php if($value['pro_size']=='1'){
            	echo "xxl";
            }else{
            		echo "sm";		
        } ?></em><br>
            <!-- <span class="color-heading">Color:</span> -->
            <!-- <em class="color-desc">Navy Blue</em> -->
            <span class="color color-black" style="background-color: rgb(43,35,56)"></span><br class="clear">
            <span class="qty-heading">Qty:</span>
            <em><?php echo $value['pro_quantity']; ?></em><br>
        </div>
        <div class="promos">
            <!-- <p class="hightlight-text online-msg">asdasdasdasdasda asdasd asdasdas dasd asd asdasd asda</p> -->
        </div>
        <div class="buttons-box">
            <a href="#" data-style="383500" data-sku="19582337" data-size="902" data-color="1246" data-qty="1" aria-label="edit item selection" class="edit " tabindex="0" onclick="">edit</a>
            <a href="#" class="remove" aria-label="remove wishlist item" data-id="gi410004" onclick="">remove</a>
            <a href="#" class="add " tabindex="0" data-style="383500" data-sizetype="Regular" data-color="1246" data-size="902" data-qty="1" aria-label="add to bag" onclick="add_to_cart('<?php echo $value['pro_id']; ?>')">add to bag</a>
        </div>
        <span class="error soldout server-errors"></span>
        </div>
        <?php }} ?>
<!--  -->
    </div>
    </section>

</div>
<<div>
	
</div>
<!-- end of wishlist page -->

        <!-- Footer
        ============================================= -->

    </div><!-- #wrapper end -->

    <!-- Footer Scripts
    ============================================= -->
    <script type="text/javascript">
  var session_value = "<?php echo $session_value ?>";
  // alert(session_value);
  function add_to_cart(id)
  {
  	alert(id);
      if (typeof session_value == "undefined" || session_value == null){
            window.location.href = "<?php echo site_url(); ?>Dashboard/register";
  
           }else{
                         $.post("<?php echo site_url(); ?>/Ajaxcontroller/add_to_cart",{ 'pro_id' : id},function(data, status){
                     if (status=="success") {
                     $.post("<?php echo site_url(); ?>/Ajaxcontroller/quantity",function(data, status){
                        $("#result").html(data);
                      alert('Cart Add Sucessfully');
                   });
                 }
        

  });
        

           }

           }
</script><script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/themes/rhapsody/js/functions988b.html?ver=20152306'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-includes/js/comment-reply.min1f6a.html?ver=4.6.15'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/beaver-builder-lite-version/js/jquery.waypoints.min8de3.html?ver=1.6.0.1'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/uploads/bb-plugin/cache/2983-layout6b2c.html?ver=9c2dfa887b6cef9e2d5b79637a8e5163'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/contact-form-7431/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>

<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/contact-form-7431/includes/js/scripts5b31.js?ver=4.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/wp-includes/js/wp-embed.min1f6a.js?ver=4.6.15'></script>
 <script>
 /* form js */
 
 </script>
</body>


</html>

           
</script>