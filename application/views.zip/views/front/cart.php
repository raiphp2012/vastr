
<!-- start cart page -->



<div class="my_cart container-fluid">
        <div class="heading">
          <h1>
            <span class="shopper"></span> Shopping Cart
          </h1>
          
          <!-- <a href="#" class="visibility-cart transition is-open">X</a>     -->
        </div>
        
        <div class="cart transition is-open">
          
          <a href="#" class="btn btn-update">Update cart</a>
          
          
          <div class="table">
            
            <div class="layout-inline row th">
              <div class="col col-pro">Product</div>
              <div class="col col-price align-center "> 
                Price
              </div>
              <div class="col col-qty align-center">QTY</div>
              <div class="col">TAX</div>
              <div class="col">Total</div>
            </div>

            <?php 
             $total_price=0;

            if(isset($cart_item) && $cart_item!=''){
            			foreach ($cart_item as $key => $value) {
                      $total_price+=$value['c_price']*$value['c_quantity'];
            		
            	?>
            
            <div class="layout-inline row">
              
              <div class="col col-pro layout-inline">
                <img src="<?php echo base_url(); ?>assets/images/<?php echo $value['pro_feat_image']?>" alt="kitten" >
                <p><?php echo $value['pro_name']; ?></p>
              </div>
              
              <div class="col col-price col-numeric align-center ">
                <p>र <?php echo $value['pro_sale_price']; ?></p>
              </div>
      
             <div class="col col-qty layout-inline">
                  <input type="number" id="qnty_<?php echo $value['c_quantity']; ?>" value="<?php echo $value['c_quantity']; ?>" name="qnty" />
              </div> 

              <div class="col col-vat col-numeric">
                <p>र 2.95</p>
              </div>
              <div class="col col-total col-numeric">               
              	<p> र <?php 

                    $total_price=$value['c_quantity']*$value['c_price']; 
                echo $total_price;?></p>
              </div>

              <input type="hidden" id="cart_id_<?php echo $value['cart_id']   ?>" value="<?php   echo $value['cart_id']   ?>" >
            </div>


         
        <?php }}?>
           <<script>    
             $(document).ready(function(){
       $("#qnty_"+"<?php   echo $value['c_quantity']; ?>").change(function(){
       var qty=$("#qnty_"+"<?php   echo $value['c_quantity']; ?>").val();
        // alert(qty);
        $("#qty_"+"<?php   echo $value['cart_id']; ?>").val(qty);
        var cart_id=$("#cart_id_"+"<?php   echo $value['cart_id']; ?>").val();
                     $.post('<?php echo base_url()    ?>Ajaxcontroller/cartqtyupdate',{qty:qty,cart_id:cart_id},function(data,status){
                              alert(data);   
                                                
                                            });

                                      });
                                  });

                                </script>
        </div>
          
          <a href="#" class="btn btn-update">Update cart</a>
        
        </div>
        
      
      Resources
    
   
    

    </div>

<!-- end of cart page -->

        <!-- Footer
        ============================================= -->

    </div><!-- #wrapper end -->

    <!-- Footer Scripts
    ============================================= -->
    <script type="text/javascript">



</script><script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/themes/rhapsody/js/functions988b.html?ver=20152306'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-includes/js/comment-reply.min1f6a.html?ver=4.6.15'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/beaver-builder-lite-version/js/jquery.waypoints.min8de3.html?ver=1.6.0.1'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/uploads/bb-plugin/cache/2983-layout6b2c.html?ver=9c2dfa887b6cef9e2d5b79637a8e5163'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/contact-form-7431/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>

<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/contact-form-7431/includes/js/scripts5b31.js?ver=4.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */

/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.mina117.js?ver=2.6.11'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>/assets/wp-includes/js/wp-embed.min1f6a.js?ver=4.6.15'></script>
 <script>
 /* Set rates + misc */
 $('.visibility-cart').on('click',function(){
       
       var $btn =  $(this);
       var $cart = $('.cart');
       console.log($btn);
       
       if ($btn.hasClass('is-open')) {
          $btn.removeClass('is-open');
          $btn.text('O')
          $cart.removeClass('is-open');     
          $cart.addClass('is-closed');
          $btn.addClass('is-closed');
       } else {
          $btn.addClass('is-open');
          $btn.text('X')
          $cart.addClass('is-open');     
          $cart.removeClass('is-closed');
          $btn.removeClass('is-closed');
       }
     
                       
     });
     
         // SHOPPING CART PLUS OR MINUS
         $('a.qty-minus').on('click', function(e) {
             e.preventDefault();
             var $this = $(this);
             var $input = $this.closest('div').find('input');
             var value = parseInt($input.val());
         
             if (value > 1) {
                 value = value - 1;
             } else {
                 value = 0;
             }
         
         $input.val(value);
             
         });
     
         $('a.qty-plus').on('click', function(e) {
             e.preventDefault();
             var $this = $(this);
             var $input = $this.closest('div').find('input');
             var value = parseInt($input.val());
     
             if (value < 100) {
             value = value + 1;
             } else {
                 value =100;
             }
     
             $input.val(value);
         });
     
     // RESTRICT INPUTS TO NUMBERS ONLY WITH A MIN OF 0 AND A MAX 100
     $('input').on('blur', function(){
     
         var input = $(this);
         var value = parseInt($(this).val());
     
             if (value < 0 || isNaN(value)) {
                 input.val(0);
             } else if
                 (value > 100) {
                 input.val(100);
             }
     });

 
</script>
</body>


</html>